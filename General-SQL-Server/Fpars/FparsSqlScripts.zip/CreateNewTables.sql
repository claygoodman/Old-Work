
PRINT 'Create tables...'
GO

:On Error exit

:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_change_history.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\scripts\create_table_consldatr_distributions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_consldatr_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_consldatr_pos.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_consldatr_transactions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_invoice_distributions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_invoice_dtls.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_invoice_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_invoice_transactions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_log_table.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_po_details.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_table_po_headers.sql"


print '====Create tables Done===='
GO
