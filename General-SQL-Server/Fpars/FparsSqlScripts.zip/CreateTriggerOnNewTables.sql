
PRINT 'Create Trigger on new tables...'
GO

:On Error exit

:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_trigger_consldatr_distributions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_trigger_consldatr_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_trigger_invoice_distributions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_trigger_invoice_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_trigger_po_details.sql"


print '====Create trigger Done===='
GO
