
PRINT 'Rename views to views_saved ...'
GO

:On Error exit

:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_change_history_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\scripts\create_view_consldatr_distributions_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_consldatr_mstr_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_consldatr_pos_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_consldatr_transactions_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_invoice_distributions_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_invoice_dtls_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_invoice_mstr_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_invoice_transactions_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_log_table_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_po_details_saved.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_view_po_headers_saved.sql"


print '====Rename views to views_saved Done===='
GO
