
PRINT 'Insert Data into new tables...'
GO

:On Error exit

:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\scripts\insert_data_consldatr_distributions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_consldatr_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_consldatr_pos.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_consldatr_transactions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_invoice_distributions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_invoice_dtls.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_invoice_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_invoice_transactions.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_log_table.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_po_details.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_po_headers.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\insert_data_change_history.sql"


print '====Insert data Done===='
GO
