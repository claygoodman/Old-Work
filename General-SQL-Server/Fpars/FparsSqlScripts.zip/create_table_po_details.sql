USE [Fpars]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

if exists (select * 
			from dbo.sysobjects 
			where id = object_id(N'[dbo].[po_details]') 
			and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[po_details]
GO

CREATE TABLE [dbo].[po_details](
	[partn_key] [int] NOT NULL,
	[po_number] [varchar](20) NOT NULL,
	[po_status] [char](1) NOT NULL,
	[company_id] [int] NOT NULL,
	[nmg_company_code] [smallint] NOT NULL,
	[fpars_company_code] [smallint] NOT NULL,
	[line_item_number] [smallint] NOT NULL,
	[item_desc] [varchar](30) NULL,
	[qty_ordered] [int] NULL,
	[units] [varchar](10) NULL,
	[usd_cost_per_unit] [money] NULL,
	[local_cost_per_unit] [money] NULL,
	[expctd_recpt_date] [datetime] NULL,
	[ship_date] [datetime] NULL,
	[cancel_date] [datetime] NULL,
	[qty_recvd] [smallint] NULL,
	[qty_cancelled] [smallint] NULL,
	[catalog_id] [varchar](15) NULL,
	[vndr_style] [varchar](30) NULL,
	[nmg_style] [varchar](30) NULL,
	[inventory_desc] [varchar](30) NULL,
	[color_desc] [varchar](20) NULL,
	[size_desc] [varchar](20) NULL,
	[manuf_ref_number] [varchar](20) NULL,
	[manuf_weight_lbs] [smallint] NULL,
	[manuf_length_inches] [smallint] NULL,
	[manuf_width_inches] [smallint] NULL,
	[manuf_height_inches] [smallint] NULL,
	[comment] [varchar](30) NULL,
	[GOH_recpt_routing] [varchar](10) NULL,
	[distrib_cntr_control_number] [varchar](10) NULL,
	[cntry_of_origin] [varchar](15) NULL,
	[upc_code] [varchar](15) NULL,
	[material_content] [varchar](10) NULL,
	[dept_id] [int] NULL,
	[dept_code] [int] NULL,
	[perishable_code] [varchar](5) NULL,
	[breakable_ind] [char](1) NULL,
	[dunnage_ind] [char](1) NULL,
	[vndr_packaging_ind] [char](1) NULL,
	[reship_ind] [char](1) NULL,
	[reship_container_ind] [char](1) NULL,
	[podtl_rec_chcksum] [int] NULL,
	[podtl_crtd_date] [datetime] NULL,
	[podtl_crtd_work_id] [int] NULL,
	[podtl_upd_date] [datetime] NULL,
	[podtl_upd_work_id] [int] NULL
) ON [po_det]

GO

--ctreate PRIMARY KEY CLUSTERED 
ALTER TABLE [dbo].[po_details] 
ADD CONSTRAINT PK_po_details PRIMARY KEY CLUSTERED 
(
	[partn_key] ASC,
	[nmg_company_code] ASC,
	[po_number] ASC,
	[line_item_number] ASC
)WITH FILLFACTOR = 90 ON [po_det]



GO


