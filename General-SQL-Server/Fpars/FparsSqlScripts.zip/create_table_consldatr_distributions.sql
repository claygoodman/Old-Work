USE [Fpars]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

if exists (select * from dbo.sysobjects 
		   where id = object_id(N'[dbo].[consldatr_distributions]') 
		   and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[consldatr_distributions]
GO

CREATE TABLE [dbo].[consldatr_distributions](
	[PARTN_KEY] [int] NOT NULL,
	[CONSLDATR_ID] [int] NOT NULL,
	[CONSLDATR_ID_SRC] [varchar](50) NOT NULL,
	[CONSLDATRDISB_SEQUENCE] [smallint] NOT NULL,
	[CONSLDATRDISB_ACCT_ID] [int] NOT NULL,
	[CONSLDATRDISB_ACCT_NO] [varchar](50) NULL,
	[CONSLDATRDISB_CODE_LEGACY] [varchar](35) NOT NULL,
	[CONSLDATRDISB_CODE_TYPE] [varchar](20) NULL,
	[CONSLDATRDISB_AMT] [money] NULL,
	[COMPANY_ID] [int] NOT NULL,
	[NMG_COMPANY_CODE] [int] NULL,
	[FPARS_COMPANY_CODE] [int] NULL,
	[DEPT_ID] [int] NOT NULL,
	[DEPT_CODE] [smallint] NULL,
	[LOCATION_ID] [int] NOT NULL,
	[NMG_LOC_STORE_NO] [smallint] NULL,
	[CONSLDATRDISB_STATUS] [char](1) NULL,
	[CONSLDATRDISB_CRTD_DTTM] [datetime] NULL,
	[CONSLDATRDISB_CRTD_WORK_ID] [int] NULL,
	[CONSLDATRDISB_UPD_DTTM] [datetime] NULL,
	[CONSLDATRDISB_UPD_WORK_ID] [int] NULL,
	[CONSLDATRDISB_CHKSUM] [int] NULL
) ON [con_dist]

GO


--primary key
ALTER TABLE [dbo].[consldatr_distributions] 
ADD CONSTRAINT PK_consldatr_distributions PRIMARY KEY CLUSTERED 
(
	[PARTN_KEY] ASC,
	[CONSLDATR_ID] ASC,
	[CONSLDATR_ID_SRC] ASC,
	[CONSLDATRDISB_SEQUENCE] ASC
)WITH FILLFACTOR = 90 ON [con_dist]

GO

