
PRINT 'Create Index on new tables...'
GO

:On Error exit

:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_index_invoice_mstr.sql"
:r "C:\Documents and Settings\Hong Rong\My Documents\MillerAssociates\NM\Fpars\HongModified\Scripts\create_index_invoice_transactions.sql"


print '====Create index Done===='
GO
